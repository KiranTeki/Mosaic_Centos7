from .base import *

MYSQL = {
    'host': '',
    'port': '3306',
    'database': 'maxiq',
    'username': 'root',
    'password': 'maxiq',
}

HIVE = {
    'host': '',
    'port': '10000',
    'database': 'default',
}

HBASE = {
    'host': '',
    'port': '',
    'database': '',
}
