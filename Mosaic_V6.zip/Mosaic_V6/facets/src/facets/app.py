import os
import json
import base64
import pandas

from sklearn.model_selection import train_test_split
from flask import Response, Blueprint, render_template

from facets.db import *
from facets.google.generic_feature_statistics_generator import GenericFeatureStatisticsGenerator


app = Blueprint(
    'facets',
    __name__,
    static_folder='static',
    template_folder='templates',
    static_url_path='/static/facets'
)


@app.route('/visualization/facets/overview/')
@app.route('/visualization/facets/overview/<string:data_source>')
def facets_overview(data_source=''):
    if not data_source:
        pwd = os.path.dirname(__file__)
        with open('{}/static/sample-data/facets-overview.data'.format(pwd)) as f:
            data = f.read()
    else:

        # get DS configuration
        configuration = Configuration(data_source)

        # handle hive tables
        if configuration.file_store_object == 'HDFS':
            table = HiveTable(data_source)
            data_frame = pandas.DataFrame([x for x in table.records], columns=[x[0] for x in table.headers])

        # handle hbase tables
        elif configuration.file_store_object == 'HBASE':
            table = HbaseTable(data_source)
            data_frame = pandas.DataFrame(table.records)

        # handle unknown
        else:
            return 'Unknown data source'

        # construct dataframe and perform profiling
        train_data = data_frame.sample(frac=0.8, random_state=200)
        test_data = data_frame.drop(train_data.index)
        gfsg = GenericFeatureStatisticsGenerator()
        proto = gfsg.ProtoFromDataFrames([{'name': 'train', 'table': train_data},
                                          {'name': 'test', 'table': test_data}])
        data = base64.b64encode(proto.SerializeToString()).decode("utf-8")

    # render facets overview
    return render_template('overview.html', data=data)


@app.route('/visualization/facets/dive/')
@app.route('/visualization/facets/dive/<string:data_source>')
def facets_dive(data_source=''):
    return render_template('dive.html', data_source=data_source)


@app.route('/api/visualization/facets/overview/')
@app.route('/api/visualization/facets/overview/<string:data_source>')
def facets_overview_api(data_source=''):
    return 'To be implemented'


@app.route('/api/visualization/facets/dive/')
@app.route('/api/visualization/facets/dive/<string:data_source>')
def facets_dive_api(data_source=''):
    try:
        if not data_source:
            pwd = os.path.dirname(__file__)
            with open('{}/static/sample-data/facets-dive.data'.format(pwd)) as f:
                data = f.read()
        else:

            # get DS configuration
            configuration = Configuration(data_source)

            # handle hive tables
            if configuration.file_store_object == 'HDFS':
                table = HiveTable(data_source)

            # handle hbase tables
            elif configuration.file_store_object == 'HBASE':
                table = HbaseTable(data_source)

            # unknown data source
            else:
                return 'Unknown data source'

            data_frame = pandas.DataFrame([x for x in table.records], columns=[x[0] for x in table.headers])
            data = data_frame.to_json(orient='records')
        return Response(data, mimetype='application/json')
    except Exception as ex:
        print(ex)
        return 'Some exception occured. Please try again after sometime.'
