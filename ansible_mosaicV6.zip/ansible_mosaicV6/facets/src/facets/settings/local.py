from .base import *

MYSQL = {
    'host': 'ip-10-0-1-186.ec2.internal',
    'port': '3360',
    'database': 'maxiq',
    'username': 'root',
    'password': 'maxiq',
}

HIVE = {
    'host': 'ip-10-0-1-206.ec2.internal',
    'port': '10000',
    'database': 'default',
}

HBASE = {
    'host': 'ip-10-0-1-206.ec2.internal',
    'port': '',
    'database': '',
}
